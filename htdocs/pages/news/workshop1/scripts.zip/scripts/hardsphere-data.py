#!/usr/bin/python
#Load the xml library
import xml.etree.ElementTree as ET

densities=[0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3]
#Create an empty list, ready to collect the pressures within
pressures=[]
for density in densities:
    outputfile="output."+str(density)+".xml"
    xmldoc = ET.parse(outputfile)
    PressureTag=xmldoc.find("./Misc/Pressure")
    #Append the pressure value (after converting it from a string to a float)
    pressures.append(float(PressureTag.attrib["Avg"]))

import matplotlib as mp
mp.plot(densities, pressures)
