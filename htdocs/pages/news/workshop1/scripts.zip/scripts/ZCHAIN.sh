#!/bin/bash

T=100
SIGMA=1
EQUIL=1000000
COLLISIONS=100000


rm -f output.xml

for CONFIG in $(ls config.?.??.xml.bz2); do
    RHO=${CONFIG#config.}
    RHO=${RHO%.xml.bz2}
#    dynamod --zero-momentum --rescale-T ${T} -o ${CONFIG} ${CONFIG}
#    dynarun --engine 1 -c ${COLLISIONS} --equilibrate ${CONFIG}
    dynarun --engine 1 -c ${COLLISIONS} ${CONFIG}
    bunzip2 output.xml.bz2
    mv output.xml output.${RHO}.xml
done
	   
