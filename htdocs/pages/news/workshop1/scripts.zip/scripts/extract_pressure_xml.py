#!/usr/bin/python

from bz2 import BZ2File
from glob import glob
import xml.etree.ElementTree as ET


filelist = glob('output.?.??.xml')
filelist.sort()
print filelist
for outputfile in filelist:

    XML = ET.parse(outputfile)

    
    T = float( XML.findall('.//Temperature')[0].attrib['Mean'] )
    p = float( XML.findall('.//Pressure')[0].attrib['Avg'] )
    rho = float( XML.findall('.//Density')[0].attrib['val'] )
    beta_p = p/T

    print T, rho, beta_p
