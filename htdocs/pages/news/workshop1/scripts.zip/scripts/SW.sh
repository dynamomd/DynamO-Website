#!/bin/bash

# Make some initial configs, this is an HP polymer
#SEQUENCE="0011011000011110100110111111001000011111110000010001010111001000"
SEQUENCE="00000000000000000000"
N=$(echo -n ${SEQUENCE} | wc -m)
SIGMA=1.6
T_LIST="0.15 0.2 0.3 0.5 0.8 1"


i=0
for T in ${T_LIST}; do
    dynamod -m 2 --i1 ${N} --f1 ${SIGMA} -T ${T} \
	    -o config.$i.start.xml.bz2 || exit 1
    i=$((i+1))
done

################################################################################
# run equilibration simulation
echo "INITIATING EQUILIBRATION RUN"

TIME_EQUIL=1000

dynarun config.*.start.xml.bz2 \
	--engine 2 -i 1 -f ${TIME_EQUIL} 


TIME=10000
ENERGY_BIN_WIDTH=0.01
dynarun config.*.end.xml.bz2         \
	--engine 2 -i 1 -f ${TIME}  \
	-L ContactMap \
	-L IntEnergyHist:BinWidth=${ENERGY_BIN_WIDTH}

dynahist_rw output.*.xml.bz2
xmgrace output.*Hist
