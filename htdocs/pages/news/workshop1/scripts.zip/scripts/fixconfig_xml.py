#!/usr/bin/python

import xml.etree.ElementTree as ET
from optparse import OptionParser


################################################################################
################################################################################
################################################################################
# parse command line arguments
usage = "usage: %prog [options] arg"
parser = OptionParser(usage)
parser.add_option("--i", type="string", dest="config_in", default='config.out.xml')
parser.add_option("--o", type="string", dest="config_out", default='config.out.xml')

(options, args) = parser.parse_args()


################################################################################
################################################################################
################################################################################
outputfile = options.config_in
XML_root = ET.parse(outputfile)

xml_pt = XML_root.findall('.//Pt')
N = len(xml_pt)


xml_list = XML_root.findall('.//Interaction')
for xml_interaction in xml_list:
    print xml_interaction.attrib['Type']
    if (xml_interaction.attrib['Type'] == 'SquareBond'):
        xml = xml_interaction.find('.//IDPairRange')
        xml.attrib['End'] = str(N-1)
for xml in xml_interaction.findall('.//CaptureMap'):
    xml_interaction.remove(xml)

#for xml in xml_list:
#    XML_root.remove(xml)
#print len(xml)
#print xml[0].tostring()
#XML_root.getroot().remove(xml)
        
#XML_root.write(options.config_out)
#xml_interaction = XML_root('//Interaction[@Type='SquareBond']/IDPairRange')[0]
#xml_interaction.set('End', str(N-1))
#
XML_root.write(options.config_out)

#file = bz2.BZ2File( options.config_out, 'w')
#file.write( etree.tostring(root, pretty_print="true") )
#file.close()


################################################################################


################################################################################
################################################################################
################################################################################
