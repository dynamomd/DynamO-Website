#!/bin/bash

T=100
N=16
SIGMA=1
EQUIL=1000000
COLLISIONS=10000000
NCELL=3


# create a single chain
dynamod --pack-mode 2 --i1 ${N} --f1 ${SIGMA} --thermostat ${T} \
	-o config.out.xml

# pack
dynamod --pack-mode 3 --density 0.001 \
	--i1 0 --xcell ${NCELL} --ycell ${NCELL} --zcell ${NCELL}  \
	--s1 config.out.xml  \
	-o config.out.xml
     
# fix bonding
./fixconfig_xml.py --i config.out.xml --o config.out.xml
bzip2 config.out.xml

# compress
for RHO in $(seq --format=%04.2f 0.1 0.1 1); do
    dynarun --engine 3 --growth-rate 10 --target-density ${RHO} \
	    config.out.xml.bz2
    dynamod --zero-momentum --rescale-T ${T} -o config.out.xml.bz2 \
	    config.out.xml.bz2 
    cp config.out.xml.bz2 config.${RHO}.xml.bz2
done
	   
