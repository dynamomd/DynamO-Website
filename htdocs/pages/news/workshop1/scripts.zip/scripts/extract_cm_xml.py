#!/usr/bin/python

import xml.etree.ElementTree as ET
from optparse import OptionParser
from pylab import *


################################################################################
################################################################################
################################################################################
# parse command line arguments
usage = "usage: %prog [options] arg"
parser = OptionParser(usage)
parser.add_option("--i", type="string", dest="outputfile", default='output.xml')
parser.add_option("--rho", type="float", dest="rho", default=0.8)
parser.add_option("--mix", type="float", dest="mix", default=0.5)
parser.add_option("--grid", type="int", dest="grid", default=10)
parser.add_option("--dr", type="float", dest="dr", default=0.05)

(options, args) = parser.parse_args()


################################################################################
################################################################################
################################################################################
outputfile = options.outputfile
XML_root = ET.parse(outputfile)

T = float( XML_root.findall('.//Temperature')[0].attrib['Mean'] )
print T

XML_cmap = XML_root.findall('.//ContactMap/HelixPolymer')[0]
lines = (XML_cmap.text).split('\n')
cmap = []
for line in lines:
    data = line.split()
    if (len(data) > 0):
        row = []
        for item in data:
            x = float( item )
            row.append( x )
        cmap.append( row )

matshow(cmap, cmap=cm.gray)
show()
