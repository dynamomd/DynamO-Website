#!/usr/bin/python
#Load the os functions
import os

#Create a list of densities to explore
densities=[0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3]
for density in densities:
    #Name files uniquely so that they are not overwritten
    startfile="config.start."+str(density)+".xml"
    equilfile="config.equilibrated."+str(density)+".xml"
    endfile="config.equilibrated."+str(density)+".xml"
    outputfile="output."+str(density)+".xml"

    #Run the simulation commands, inserting the computed variables
    os.system("dynamod -m 0 -d "+str(density)+" -C 7 -o "+startfile)
    os.system("dynarun "+startfile+" -c 100000 -o "+equilfile)

    #Ensure that the output data file for the last run has a unique name
    os.system("dynarun "+equilfile+" -c 1000000 -o "+endfile 
              +" --out-data-file="+outputfile)
